from rest_framework import viewsets, status
from rest_framework.response import Response
from rest_framework.decorators import action
from .models import *
from .serializers import *

class StockViewSet(viewsets.ModelViewSet):
    queryset = Stock.objects.all()
    serializer_class = StockSerializer
    #permission_classes = [permissions.IsAuthenticated]

class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    '''
    def get_permissions(self):
        if self.action == 'create':
            return [permissions.AllowAny()]
        return [permissions.IsAuthenticated()]
    '''

class ProductViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer
    #permission_classes = [permissions.IsAuthenticated]

class StockInViewSet(viewsets.ModelViewSet):
    queryset = StockIn.objects.all().order_by('-created_at')
    serializer_class = StockInSerializer
    #permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

class StockOutViewSet(viewsets.ModelViewSet):
    queryset = StockOut.objects.all().order_by('-created_at')
    serializer_class = StockOutSerializer
    #permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

class ProductInStockViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = ProductInStock.objects.all()
    serializer_class = ProductInStockSerializer
    #permission_classes = [permissions.IsAuthenticated]